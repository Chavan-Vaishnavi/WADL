const dbConnect=require('./mongodb');
const express=require('express');
const app=express();
app.use(express.json())

app.get('/getData',async(req,res)=>{
    let result=await dbConnect();
    result=awaitresult.find().toarray();
    res.send(result);
})

app.post('/insertData',asyns(req,res)=>{
    let result=await dbConnect();
    result=await result.insertOne(req.body);
    res.send("Data Inserted Successfully")
})

app.put('/updatedata/:name',async(req,res)=>{
    let result=await dbConnect();
    result=await result.update({name:req.params.name},{$set:req.body});
    res.send("Data Successfully Updated")
})

app.delete('/deleteData/:name',async(req,res)=>{
    let result=await dbConnect();
    result=await result.deleteOne({name:req.params.name})
    res.send("Data Successfully Deleted");
})

app.listen(3000)
